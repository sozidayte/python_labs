def Evtushenko_check_first_last(lst):    return len(lst) > 0 and lst[0] == lst[-1]
print(Evtushenko_check_first_last([1, 2, 3, 4, 5, 1]))
